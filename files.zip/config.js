/* Isi dengan konfigurasi dari Firebase Console:
   Project settings > Your apps > Web app > Config.
   Kunci ini boleh publik; keamanan diatur oleh firestore.rules. */
window.FB_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};
